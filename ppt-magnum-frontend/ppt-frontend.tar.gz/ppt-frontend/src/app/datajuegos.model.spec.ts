import { Datajuegos } from './datajuegos.model';

describe('Datajuegos', () => {
  it('should create an instance', () => {
    expect(new Datajuegos()).toBeTruthy();
  });
});
