export class Datajuegos {
}
